管绪リルカ｜音源&角色完整使用规约
 
角色档案
 
姓名：管绪リルカ
年龄：14岁
性别：男
种族：小型机器狼兽人
喜好：薄荷糖
 
可自由使用范围（无需提前联络音源管理者）
 
1. 用户可以自由创作、发布管绪リルカ的各类二次创作作品，包括但不限于音乐PV、插画、漫画、短篇故事等，同时可以公开分享该角色相关的衍生资料。
​
2. 仅限个人学习、音源调试的私人用途，使用者能够对音源文件进行修改调整，其中包含oto‑ini参数编辑、音频采样修剪、各类音频参数校正，仅允许在本地个人设备保存使用。
​
3. 允许创作带有轻度战斗场面、少量流血表现等低烈度冲突内容的二创作品，请勿制作过度血腥的画面。
​
4. 在二次创作当中可以对角色外观进行改动：更换角色服饰、调整角色年龄设定、设计不同的兽人形态变体等，丰富角色的创作可能性。
 
创作欢迎事项
 
1. 欢迎大家使用本音源制作积极向上、传递正能量的各类内容。
​
2. 非常欢迎为本音源谱写、制作各式各样的歌曲，无论是流行、古风、摇滚、电子、抒情等曲风都十分期待。
​
3. 欢迎绘制角色插画、漫画、小故事，挖掘角色的性格与世界观，丰富角色的同人生态。
​
4. 鼓励大家进行音源调校练习，多多尝试不同的调音风格，发掘这份声库更多音色可能性。
​
5. 欢迎制作PV、手书、动画短片等多媒体作品，赋予管绪リルカ更多生动的演绎。
​
6. 可以制作剧情向、叙事向音乐作品，去描绘属于这个机器狼少年的故事。
​
7. 欢迎分享你的调音心得、工程示例（未经许可不可公开发布修改后的oto文件），和同好互相交流学习。
 
需要提前取得音源管理者授权后方可开展的行为
 
注：平台管理员、社团管理员若需要开展相关活动，同样需要向音源作者提交申请获取许可。
 
1. 所有线下同人展会、线下同人相关活动，以及全部商业用途行为，无论该行为是否产生盈利收益，都必须事先向音源管理者提交申请，拿到正式授权之后才能够实施。
​
2. 一切和Cosplay相关的活动，涵盖角色服装的设计、制作、实物贩售、线下出镜扮演等全部相关行为，均需要获取管理者许可。
​
3. 使用本角色形象制作虚拟主播皮套，进行角色扮演直播、虚拟演绎等相关活动，必须提前申请授权。
​
4. 如果创作内容包含死亡情节、重口味猎奇画面、猎奇向人外化描写，在对外发布作品的时候，务必添加醒目清晰的内容警示标签，做好内容分级提示，防止对不知情的观众造成心理不适。
​
5. 当你修改完成oto.ini配置文件之后，如果计划对外公开配布这份经过修改的配置文件，必须主动向原作者提交申请，在收到明确许可之后，才可以公开发布你的修改版本。
 
明确禁止进行的行为
 
1. 在没有获得许可的情况下，不允许私自转发、二次分发整套音源文件；仅存在唯一特殊例外：原版音源已经完全无法获取，并且音源管理者本人明确同意，才允许进行二次配布。
​
2. 禁止将该音源应用于政治宣传、宗教布教传教相关的一切内容创作。
​
3. 不可以挪用管绪リルカ的音源，直接将这份声音素材充当其他全新原创角色的配音来使用。
​
4. 禁止制作CP配对、恋爱主题的各类二创内容，该角色官方感情线全部归属于原作者设定，他人不可进行相关创作。
​
5. 严禁修改、裁剪、篡改官方发布的原版角色头像插画，不可以对官方头像进行二次加工改写。
​
6. 禁止制作低俗、恶意引战、宣扬暴力、歧视他人等不良导向内容。
补充说明
 
1. 在公开发布使用该音源产出的作品时，请务必在标题、简介等醒目位置标注音源名称：管绪リルカ。
​
2. 如果创作当中需要引用其他人产出的二次创作素材，一定要提前取得对应原作者的同意，不可擅自挪用他人作品。
​
3. 本套角色设定仅供创作者作为创作参考使用，角色感情线设定、官方头像设定不允许改动，除此之外其余角色细节，创作者可以根据自身作品剧情灵活调整。
 
联系方式
如有问题请联系（QQ）:3786033638
邮件：3786033638@qq.com
 
原音修正：你们
音源采样：弦音ハルカ
音源管理：弦音ハルカ
 
欢迎使用此音源进行创作。
本使用条款已经告知使用者该如何正确使用该音源，如有任何法律纠纷均由使用者承担。

温馨提示
1. 本声库仅允许使用默认歌词 a ，不可以输入其他任何歌词，输入别的内容音源无法正常发声。
​
2. 声库全部配置文件（ character.txt 、 oto.ini 、 readme.txt ）编码必须选择 Chinese Simplified(GB2312)，参照截图示例；编码选错会直接出现乱码，声库读取失败。
​
3. OpenUTAU音素器设置：语言选择日语，音素器选用 [JA VCV] Japanese VCV Phonemizer (legacy) ，音素器选错音源不会输出声音。
​
4. 使用本音源，请严格遵守上方全部使用条约规范。
​
5. 祝您使用顺利！

English Version
 
Character Profile
 
Name: Kansuo Riruka
Age: 14
Gender: Male
Race: Small machine‑wolf beastman
Likes: Peppermint candy
 
Permitted Actions (No prior contact with the bank administrator required)
 
1. Users are free to create and publish various fan‑works of Kansuo Riruka, including music PVs, illustrations, comics, short stories and more. Derivative materials related to this character may also be shared publicly.
​
2. For personal study and voicebank tuning only, users may adjust local voicebank files, such as editing oto‑ini parameters, trimming samples and calibrating audio settings. Modified files can only be stored locally for private use.
​
3. Fan‑works containing mild combat scenes and minor blood depictions are permitted. Excessively gory visuals should be avoided.
​
4. You may adjust the character’s appearance in fan‑works, including costume changes, age adjustments, and alternative beast‑form variants to enrich your creative output.
 
Creation Welcome Notes
1. You are welcome to create positive and uplifting content with this voicebank.
​
2. We highly encourage song production for this voicebank, pop, ballad, rock, electronic and all music genres are welcomed.
​
3. Feel free to draw illustrations, comics and short stories to expand the character’s world‑building.
​
4. Tune and experiment with different vocal styles to explore the full potential of this voicebank.
​
5. PVs, hand‑drawn animations and short multimedia videos are warmly welcomed.
​
6. Narrative and story‑driven music works about this machine‑wolf boy are encouraged.
​
7. You may share your tuning experience with other creators, but modified oto.ini shall not be shared publicly without permission.
Actions Requiring Prior Written Permission From Administrator
 
Note: Platform administrators and community administrators shall also apply for permission from the voicebank author before relevant usage.
 
1. All offline doujin events and any form of commercial usage, whether profit‑making or non‑profit, must receive official authorization from the bank administrator before implementation.
​
2. All cosplay‑related activities, including costume designing, production, selling and public performance, require prior permission.
​
3. Any virtual‑youtuber streaming or virtual performance that role‑plays this character with custom avatar assets must apply for authorization in advance.
​
4. If your work includes depictions of death, heavy grotesque themes or uncanny beast‑human transformation, prominent content warning labels must be added upon release to avoid psychological distress for unprepared audiences.
​
5. If you intend to publicly distribute your self‑modified oto.ini configuration file after tuning, you must submit an application to the original author and wait for explicit approval before public release.
Prohibited Actions
 
1. Unauthorized redistribution of the full voicebank is forbidden. The sole exception applies when the original voicebank is completely unavailable and the bank administrator gives explicit consent.
​
2. This voicebank shall not be used for political propaganda or religious proselytizing of any kind.
​
3. Do not repurpose this voicebank as voice asset for other original characters.
​
4. Shipping and romantic‑themed fan‑content are strictly prohibited. Official romantic storylines are reserved exclusively for the original creator.
​
5. Do not edit, crop or alter the official original character avatar artwork. Modification or re‑editing of official avatar art is not allowed.
​
6. Content involving obscenity, harassment, hate speech, violence and discrimination is strictly forbidden.
Additional Notes
 
1. When releasing works made with this voicebank, please clearly credit the voicebank name “Kansuo Riruka” in visible areas such as title or description.
​
2. Always obtain permission from respective creators before incorporating third‑party fan‑made resources into your work.
​
3. Character settings serve only as creative reference. Romance settings and official avatar artwork cannot be altered. Other character details can be adjusted freely to fit your story.
Contact
For inquiries: QQ:3786033638
E‑mail: 3786033638@qq.com
 
Oto Editing: You
Voice Sampling: Haruka Tsurine
Bank Administrator: Haruka Tsurine
 
Welcome to create works with this voicebank.
These terms inform users of the proper way to use this voicebank. Any legal disputes arising from misuse shall be borne solely by the user.

Tips
1. Only the default lyric  a  is available for this voicebank. No other lyrics are allowed, or the voicebank will fail to produce sound.
​
2. All configuration files of this voicebank (character.txt, oto.ini, readme.txt) must be encoded with Chinese Simplified (GB2312) as shown in the screenshot. Wrong encoding will cause garbled text and make the voicebank unreadable.
​
3. OpenUTAU Phonemizer settings: select language Japanese, and choose  [JA VCV] Japanese VCV Phonemizer (legacy) . Wrong phonemizer selection will result in no audio output.
​
4. Please use this voicebank in strict accordance with all usage rules stated above.
​
5. Wish you a pleasant creation!

日本語版
 
キャラクター設定
 
名前：管緒リルカ
年齢：14歳
性別：男性
種族：小型機械オオカミ獣人
好きなもの：ミントキャンディ
 
管理者に連絡不要で実行可能な行為
 
1. ユーザーはPV、イラスト、漫画、短編小説など、管緒リルカの各種二次創作を自由に制作・公開できます。キャラクターに関する派生資料も公開共有可能です。
​
2. 個人の学習、音源調整を目的とする場合に限り、ローカルの音源ファイルを編集できます。oto‑iniのパラメータ修正、サンプルのトリミング、オーディオ補正などが含まれ、改変ファイルは個人端末内でのみ保存してください。
​
3. 軽度な戦闘シーン、少量の流血表現を含む二次創作は許可されます。過激なグロ表現は避けてください。
​
4. 二次創作において衣装変更、年齢設定の調整、獣人態の別バージョン作成など、キャラクター外見のアレンジを行うことができ、創作の幅を広げられます。

創作歓迎事項
 
1. 前向きで良いメッセージを持った作品の制作を歓迎いたします。
​
2. 本音源での楽曲制作を大歓迎します。ポップ、バラード、ロック、エレクトロなどジャンルを問わず期待しています。
​
3. イラスト、漫画、短編物語を作成し、キャラクターの世界観を広げてください。
​
4. 様々な調声スタイルに挑戦し、音源の新たな可能性を引き出す練習を推奨します。
​
5. PV、手書きアニメ、ショートムービーなどマルチメディア作品の制作も歓迎します。
​
6. この機械オオカミ少年を描いた物語性のある楽曲の制作を応援します。
​
7. 調声のノウハウを同好と共有することを推奨します。ただし許可なしに改変oto.iniを公開配布してはいけません。
事前に管理者の許可を取得する必要がある行為
 
備考：プラットフォーム管理者・サークル管理者が利用する場合も、音源作者へ申請を行い許可を得る必要があります。
 
1. オフライン同人イベント、あらゆる商業利用については、営利・非営利に関わらず、事前に管理者へ申請を行い正式な許可を得た上で実施してください。
​
2. 衣装のデザイン、制作、販売、実際のコスプレ出演など、コスプレに関するすべての行為に許可が必要です。
​
3. 本キャラクターを模したVtuberの皮膚を作成し、なりきり配信やバーチャル演技を行う場合は事前に申請し許可を受けてください。
​
4. 死亡描写、過激なグロテスク表現、猎奇的な人外化描写を含む作品を公開する際は、必ず目立つ注意喚起ラベルを付け、知らない視聴者に精神的負担を与えないよう配慮してください。
​
5. 修正済みのoto.iniファイルを外部へ配布したい場合、必ず原作者に申請し、明確な許可を受けてから公開してください。

禁止行為
 
1. 無断で音源一式を再配布することを禁じます。例外は、元音源が完全に入手不可能になり、かつ音源管理者本人が明示的に許可した場合のみです。
​
2. 政治宣伝、宗教布教を目的として本音源を使用してはいけません。
​
3. 管緒リルカの音源を、別のオリジナルキャラクターのボイス素材として流用しないでください。
​
4. CP、恋愛をテーマにした二次創作は一切禁止します。キャラクターの恋愛設定は原作者が独占的に管理します。
​
5. 公式公開済みのキャラクターアバターイラストの加工、トリミング、改変を行ってはいけません。
​
6. 低俗、誹謗中傷、暴力、差別を含む作品の制作を固く禁じます。

補足
 
1. 本音源を使用し制作した作品を公開する時は、タイトルや概要欄など目につきやすい場所に音源名「管緒リルカ」を表記してください。
​
2. 第三者の二次創作物を自身の作品に利用する場合は、事前に該当作者の許可を取得し、無断転用をしないでください。
​
3. キャラクター設定は創作の参考資料に過ぎません。恋愛設定と公式アバターイラストは改変不可、それ以外の細かい設定は物語に合わせて自由に調整できます。
 
連絡先
ご質問がある場合：QQ:3786033638
メール：3786033638@qq.com
 
原音修正：あなたたち
音源サンプリング：弦音ハルカ
音源管理：弦音ハルカ
 
この音源を使った創作を歓迎します。
本利用規約は音源の正しい使用方法を使用者に告知しています。万が一法律的な紛争が発生した場合、すべて使用者が責任を負うものとします。

ヒント
1. このボイスバンクは既定歌詞の a のみ使用可能です。それ以外の歌詞を入力すると正常に発音しません。
​
2. ボイスバンクの設定ファイル（character.txt、oto.ini、readme.txt）はすべてChinese Simplified(GB2312) エンコードで保存してください。スクリーンショット通りに設定しないと文字化けが発生し、音源が読み込めなくなります。
​
3. OpenUTAUのフォネマイザー設定：言語を日本語に選択し、 [JA VCV] Japanese VCV Phonemizer (legacy) を選んでください。フォネマイザーの選択ミスは音が出ない原因になります。
​
4. 本音源は上記に記載された利用規約を厳守して使用してください。
​
5. 創作が上手くいきますように！

